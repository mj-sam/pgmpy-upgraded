the package upgraded by mohamad javad sameri
detail added to package :
	* estimation:
		*AIC score function
		*Fnml score function
	* added model_evaluation metric :
		* SHD
		* AHD
		* Accuracy
		* Sensitivity
